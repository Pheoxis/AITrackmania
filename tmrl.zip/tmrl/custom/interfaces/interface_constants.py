NB_OBS_FORWARD = 500  # this allows (and rewards) 50m cuts
