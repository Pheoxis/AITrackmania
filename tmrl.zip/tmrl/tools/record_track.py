def record_track_map():
    pass